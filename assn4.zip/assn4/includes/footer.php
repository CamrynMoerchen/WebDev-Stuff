<!-- Name: Camryn Moerchen -->
<!-- Student Number: 0723708 -->
<!-- COIS-3420H Assignment 4 -->
<!-- Page: footer.php -->
<!-- Page Description: This is the php wrapper for the footer-->

<!--Footer of the page that contains my name and the year.-->
<footer>
  <span>&#169; 2023 Camryn Moerchen</span>
</footer>