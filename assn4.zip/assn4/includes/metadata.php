<!-- Name: Camryn Moerchen -->
<!-- Student Number: 0723708 -->
<!-- COIS-3420H Assignment 4 -->
<!-- Page: metadata.php -->
<!-- Page Description: This is a php wrapper for the metadata.-->

<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script src="https://kit.fontawesome.com/8101aa1878.js" crossorigin="anonymous"></script> <!-- Getting FontAwesome -->
<link rel="stylesheet" href="styles/main.css" /> <!-- Getting the stylesheet -->